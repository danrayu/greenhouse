#ifndef _TELEMETRIX4ARDUINO_H_
#define _TELEMETRIX4ARDUINO_H_

class Telemetrix4Arduino {

public:
};

#endif //_TELEMETRIX4ARDUINO_H_
