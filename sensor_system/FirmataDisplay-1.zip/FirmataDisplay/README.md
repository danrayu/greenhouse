This library is an enhanced version of Arduino StandardFirmata 2.5.8. It was designed to by used
in conjunction with the Python based [pymata-express Telemetrix client](https://github.com/MrYsLab/telemetrix).
It is based on the work of Alan Yoricks and has been hacked to additionally support the 8 segment LCD display on the Rich Shield.

It supports all the features of StandardFirmata2.5.8, and additionally adds support for

* DHT Humidity/Temperature Sensors
* Rich Shield 8 segment display
* Advanced Auto-Discovery Of Connected Arduino Boards
* Runs At A BaudRate of 115200

